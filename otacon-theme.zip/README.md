# Otacon Desk Sprite

A fan-made Otacon pixel theme for Clawd on Desk.

## Contents

- `otacon-theme/`: the Clawd theme folder, including `theme.json` and `assets/`.
- `sound-overrides/otacon-theme/`: optional sound overrides for the Otacon theme.

## Install

1. Install Clawd on Desk first.
2. Copy `otacon-theme/` to:

   `~/Library/Application Support/clawd-on-desk/themes/otacon-theme/`

3. Optional: copy `sound-overrides/otacon-theme/` to:

   `~/Library/Application Support/clawd-on-desk/sound-overrides/otacon-theme/`

4. Restart Clawd on Desk and choose the `Otacon` theme.

## Note

Fan-made theme for personal/non-commercial use. Original character/artwork rights belong to their respective owners.
