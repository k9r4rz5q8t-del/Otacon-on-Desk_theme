# Installation paths

Theme folder:
~/Library/Application Support/clawd-on-desk/themes/otacon-theme/

Sound override folder:
~/Library/Application Support/clawd-on-desk/sound-overrides/otacon-theme/

After copying both folders, restart Clawd on Desk and select the Otacon theme.
